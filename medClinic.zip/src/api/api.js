export const doctorsApi = 'https://64f54ff9da223d72.mokky.dev/doctors';
export const servicesApi = 'https://64f54ff9da223d72.mokky.dev/service';
export const recordsApi = 'https://64f54ff9da223d72.mokky.dev/records';
export const reviewsApi = 'https://64f54ff9da223d72.mokky.dev/reviews';